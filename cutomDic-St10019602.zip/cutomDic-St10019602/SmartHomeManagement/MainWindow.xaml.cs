﻿using System.Windows;
using System.Windows.Controls;

namespace SmartHomeManagement
{
    public partial class MainWindow : Window
    {
        private CustomDictionary<string, string> devices;

        public MainWindow()
        {
            InitializeComponent();
            devices = new CustomDictionary<string, string>();
        }

        private void AddDevice_Click(object sender, RoutedEventArgs e)
        {
            string deviceId = DeviceIdTextBox.Text;
            string status = (StatusComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();

            if (!string.IsNullOrEmpty(deviceId) && !string.IsNullOrEmpty(status))
            {
                devices.Add(deviceId, status);
                RefreshDeviceList();
            }
            else
            {
                MessageBox.Show("Please enter a valid device ID and select a status.");
            }
        }

        private void UpdateDevice_Click(object sender, RoutedEventArgs e)
        {
            string deviceId = DeviceIdTextBox.Text;
            string status = (StatusComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();

            if (devices.ContainsKey(deviceId))
            {
                devices.Update(deviceId, status);
                RefreshDeviceList();
            }
            else
            {
                MessageBox.Show("Device ID not found.");
            }
        }

        private void RemoveDevice_Click(object sender, RoutedEventArgs e)
        {
            string deviceId = DeviceIdTextBox.Text;

            if (devices.Remove(deviceId))
            {
                RefreshDeviceList();
            }
            else
            {
                MessageBox.Show("Device ID not found.");
            }
        }

        private void RefreshDeviceList()
        {
            DeviceListBox.Items.Clear();
            foreach (var device in devices.GetAllItems())
            {
                DeviceListBox.Items.Add($"Device ID: {device.Key}, Status: {device.Value}");
            }
        }
    }
}

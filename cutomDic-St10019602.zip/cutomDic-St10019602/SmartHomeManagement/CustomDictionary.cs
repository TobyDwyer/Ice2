﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartHomeManagement
{
    public class CustomDictionary<TKey, TValue>
    {
        private Dictionary<TKey, TValue> _dictionary = new Dictionary<TKey, TValue>();

        public void Add(TKey key, TValue value)
        {
            if (!_dictionary.ContainsKey(key))
            {
                _dictionary.Add(key, value);
            }
        }

        public bool Update(TKey key, TValue value)
        {
            if (_dictionary.ContainsKey(key))
            {
                _dictionary[key] = value;
                return true;
            }
            return false;
        }

        public bool Remove(TKey key)
        {
            return _dictionary.Remove(key);
        }

        public TValue GetValue(TKey key)
        {
            if (_dictionary.TryGetValue(key, out TValue value))
            {
                return value;
            }
            return default(TValue);
        }

        public bool ContainsKey(TKey key)
        {
            return _dictionary.ContainsKey(key);
        }

        public Dictionary<TKey, TValue> GetAllItems()
        {
            return _dictionary;
        }
    }
}
